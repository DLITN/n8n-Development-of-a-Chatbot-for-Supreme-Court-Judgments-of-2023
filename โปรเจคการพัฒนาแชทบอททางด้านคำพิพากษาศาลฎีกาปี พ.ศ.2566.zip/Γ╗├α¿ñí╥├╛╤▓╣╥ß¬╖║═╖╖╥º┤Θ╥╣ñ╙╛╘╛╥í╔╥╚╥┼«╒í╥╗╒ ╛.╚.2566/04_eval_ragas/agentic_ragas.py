# --- FAQ ---
# 1. ตรงไหนที่ระบุว่าไปหาข้อมูลจากฐานข้อมูลใน Supabase?
# จุดที่ Code ทำการ "วิ่งออกไปหาข้อมูล" จาก Supabase จริงๆ ไม่ใช่การจำลอง อยู่ที่ 2 จุดหลัก นี้ครับ:

# จุดที่ 1: คำสั่งค้นหา (Query Execution) อยู่ในฟังก์ชัน retrieve_and_rerank (ประมาณบรรทัดที่ 70-76) คำสั่งนี้จะยิง Request ไปที่ Supabase Vector Store ครับ
# บรรทัดที่ 72-75: คำสั่งนี้คือการ "ยิงคำถามไปที่ Supabase" โดยตรง
# docs = vector_store.similarity_search(
#     query, 
#     k=20, 
#     filter={"judgment_id": case_id} # <-- Filter ตามเลขคดีใน Supabase
# )
# จุดที่ 2: การเรียกใช้งานใน Loop (Actual Call) อยู่ใน Loop การทดสอบ (บรรทัดที่ 115) คำสั่งนี้สั่งให้ Retriever ทำงานจริงเพื่อดึงเอกสารออกมา
# # บรรทัดที่ 115: สั่งให้ Compression Retriever (ที่ห่อ Supabase ไว้) ทำงาน
# retrieved_docs = compression_retriever.invoke(input_payload)

# # บรรทัดที่ 116: print จำนวนเอกสารที่ "เจอจริง" จาก Supabase ออกมาดู
# print(f"   📄 เจอเอกสาร: {len(retrieved_docs)} ชิ้น")

# 2. จุดที่ยืนยันว่า GPT-4o (Judge) ไม่ได้ Hallucination หรือมั่วคะแนนขึ้นมาเอง?
# ความกังวลคือ "GPT-4o เอาอะไรมาตัดสิน? มันนั่งเทียนเขียนคะแนนหรือเปล่า?" คำตอบคือ ไม่ครับ เพราะเราบังคับให้มันตัดสินจาก "หลักฐาน" (Evidence Based) ที่เราส่งให้เท่านั้น ดูได้จากจุดเชื่อมโยงข้อมูลตรงนี้ครับ:

# ขั้นตอนที่ A: จับหลักฐานใส่กล่อง (Data Binding) หลังจากดึงข้อมูลจาก Supabase แล้ว คุณเอาเนื้อหา (Text) นั้นมาเก็บใส่ตัวแปร current_contexts ทันที (ประมาณบรรทัดที่ 121)
# # บรรทัดที่ 121: "นี่คือหลักฐาน!" -> เอาข้อความจาก Supabase มาเก็บไว้เป็นหลักฐานอ้างอิง
# current_contexts = [doc.page_content for doc in retrieved_docs]

# # บรรทัดที่ 128: เอาหลักฐานใส่ List รวมไว้
# contexts_list.append(current_contexts)

# ขั้นตอนที่ B: ส่งหลักฐานไปให้ Ragas (GPT-4o) ตรวจสอบคะแนน (ประมาณบรรทัดที่ 142-157)
# Input: เริ่มจาก user_input (คำถาม) ที่คุณเตรียมไว้
# Retrieval: โค้ดวิ่งไปดึงข้อมูลจริงจาก Supabase และกรองด้วย Reranker ได้ออกมาเป็น retrieved_contexts
# Generation: ส่งข้อมูลไปให้ Typhoon เขียนตอบ ได้ออกมาเป็น response
# Evaluation: ส่งข้อมูลทั้งหมด (user_input, response, retrieved_contexts, reference) ไปให้ GPT-4o ทำหน้าที่เป็นกรรมการตรวจให้คะแนน 3 ด้าน (answer_correctness, faithfulness, context_precision)

# Output: บันทึกผลทั้งหมดลงไฟล์ CSV

import json
import os
import pandas as pd
from dotenv import load_dotenv
from pathlib import Path

# Library สำหรับต่อ Supabase
from langchain_community.vectorstores import SupabaseVectorStore
from supabase.client import create_client, Client
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

# HuggingFace & Ollama (สำหรับ Player)
from langchain_huggingface import HuggingFaceEmbeddings 
from langchain_ollama import ChatOllama

# ✅ OpenAI (สำหรับ Judge)
from langchain_openai import ChatOpenAI

# Reranker
from langchain_community.document_compressors.flashrank_rerank import FlashrankRerank

# ✅ Ragas Metrics (เพิ่มให้ครบ 4 ด้าน)
from ragas.run_config import RunConfig
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import (
    answer_correctness, 
    faithfulness,       # เช็ค Hallucination (Generation)
    context_precision,  # เช็คความแม่นยำ Context (Retrieval)
    context_recall,     # ✅ เพิ่ม: เช็คความครบถ้วนของ Context (Retrieval)
    answer_relevancy    # ✅ เพิ่ม: เช็คว่าตอบตรงคำถามไหม (Generation)
)

# --- 1. Load Config ---
current_dir = Path(__file__).resolve().parent
env_path = current_dir / "api.env"
load_dotenv(dotenv_path=env_path)

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY") 

if not all([SUPABASE_URL, SUPABASE_KEY, OPENAI_API_KEY]):
    raise ValueError("❌ กรุณาใส่ SUPABASE_URL, SUPABASE_KEY และ OPENAI_API_KEY ในไฟล์ api.env")

# --- 2. Setup Models ---

print("🚀 กำลังโหลด E5-Large Embedding (ใช้ Local)...")
retrieval_embeddings = HuggingFaceEmbeddings(
    model_name="intfloat/multilingual-e5-large",
    model_kwargs={'device': 'cpu'}
)

print("🤖 กำลังเชื่อมต่อกับ Player (Typhoon Local)...")
player_llm = ChatOllama(model="scb10x/typhoon2.1-gemma3-4b:latest", temperature=0)

print("⚖️ กำลังเชื่อมต่อกับ Judge (GPT-4o Cloud)...")
judge_llm = ChatOpenAI(model="gpt-4o", temperature=0) 

supabase_client: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
vector_store = SupabaseVectorStore(
    client=supabase_client,
    embedding=retrieval_embeddings,
    table_name="legal_chunks",
    query_name="match_legal_chunks"
)

# --- 3. Setup Retriever with Reranker ---
print("⚡ กำลังโหลด FlashRank Reranker...")
compressor = FlashrankRerank(model="ms-marco-MiniLM-L-12-v2", top_n=5)

def retrieve_and_rerank(inputs):
    if isinstance(inputs, dict):
        query = inputs.get("query")
        case_id = inputs.get("case_id")
    else:
        query = inputs
        case_id = None

    print(f"   🔍 Searching for: '{query[:20]}...' (Case ID: {case_id})")

    if case_id:
        docs = vector_store.similarity_search(
            query, k=20, filter={"judgment_id": case_id}
        )
    else:
        docs = vector_store.similarity_search(query, k=20)
    
    if docs:
        reranked_docs = compressor.compress_documents(docs, query=query)
        return reranked_docs
    else:
        return []

compression_retriever = RunnableLambda(retrieve_and_rerank)

# --- 4. Setup Chain ---
template = """
คุณคือผู้ช่วยทนายความอัจฉริยะ เชี่ยวชาญกฎหมายไทย
ตอบคำถามโดยสรุปจาก Context ด้านล่างนี้เท่านั้น

⚠️ กฎเหล็ก:
1. ตอบตามข้อมูลใน "บริบท" (Context) เท่านั้น ห้ามคิดเอง
2. หากในบริบทไม่มีคำตอบ ให้ตอบว่า "ไม่ทราบ"

บริบท:
{context}

คำถาม: {question}
คำตอบ:
"""
prompt = ChatPromptTemplate.from_template(template)

def get_question(input_dict):
    return input_dict["query"]

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

rag_chain = (
    {"context": compression_retriever | format_docs, "question": RunnableLambda(get_question)} 
    | prompt
    | player_llm 
    | StrOutputParser()
)

# --- 5. Testing Data (Golden Dataset) ---
test_inputs = {
    "question": [
        "โจทก์ที่ 1 ได้รับค่าสินไหมทดแทนในส่วนของ 'ค่าขาดไร้อุปการะ' เป็นจำนวนเงินเท่าไหร่?",
        "ทำไมศาลถึงไม่กำหนดค่าสินไหมทดแทนกรณีการถูกละเมิดสิทธิและเสรีภาพตามรัฐธรรมนูญให้แก่โจทก์?",
        "โจทก์ที่ 1 (มารดา) มีสิทธิเรียกร้อง 'ค่าขาดแรงงาน' จากการตายของบุตรหรือไม่ เพราะเหตุใด?",
        "ศาลกำหนดให้จำเลยชำระดอกเบี้ยในอัตราร้อยละ 7.5 ต่อปี ตามที่โจทก์ฎีกาหรือไม่?",
        "โจทก์ที่ 2 (ภริยา) มีสิทธิเรียกร้องค่าขาดแรงงานหรือไม่?"
    ],
    "answer": [
        "ศาลกำหนดให้จำเลยทั้งสองร่วมกันชดใช้ค่าสินไหมทดแทนเป็นค่าขาดไร้อุปการะให้แก่โจทก์ที่ 1 เป็นเงิน 1,000,000 บาท",
        "เนื่องจากประมวลกฎหมายแพ่งและพาณิชย์ ลักษณะ 5 ละเมิด หมวด 2 กรณีทำให้ถึงตาย ไม่ได้กำหนดให้เรียกค่าสินไหมทดแทนในส่วนนี้ได้ ศาลจึงไม่มีสิทธิเรียกร้องให้จำเลยชดใช้",
        "ไม่มีสิทธิ เนื่องจากขณะผู้ตายถึงแก่ความตาย ผู้ตายบรรลุนิติภาวะแล้ว โจทก์ที่ 1 จึงไม่มีสิทธิตาม ป.พ.พ. มาตรา 1567 (3) ที่จะให้ผู้ตายทำงาน",
        "ศาลไม่อาจกำหนดดอกเบี้ยให้ได้ เนื่องจากในคำฟ้องโจทก์ไม่ได้ขอให้จำเลยชำระดอกเบี้ยมาด้วย (เกินคำขอ)",
        "ไม่มีสิทธิ เนื่องจากโจทก์ที่ 2 ไม่ได้จดทะเบียนสมรสกับผู้ตาย จึงไม่ใช่สามีภริยาที่มีหน้าที่ต้องช่วยเหลืออุปการะเลี้ยงดูกันตามกฎหมาย"
    ],
    "context": [
        [
            "สมควรกําหนดให้จําเลยทั้งสองร่วมกันใช้ค่าสินไหมทดแทนเป็นค่าขาดไร้อุปการะให้แก่โจทก์ที่ 1 เป็นเงิน 1,000,000 บาท"
        ],
        [
            "ซึ่งตามบทบัญญัติดังกล่าวในหมวด 2 ค่าสินไหมทดแทนเพื่อละเมิดในกรณีทําให้ถึงตายนั้น ไม่ได้กําหนดให้เรียกค่าสินไหมทดแทนเป็นค่าที่ไม่ได้รับการเยียวยาจากการถูกละเมิดสิทธิและเสรีภาพตามรัฐธรรมนูญและกติการะหว่างประเทศว่าด้วยสิทธิพลเมืองและสิทธิทางการเมืองตามที่โจทก์ทั้งสามกล่าวอ้าง โจทก์ทั้งสามจึงไม่มีสิทธิเรียกร้องให้จําเลยทั้งสองใช้ค่าสินไหมทดแทนได้"
        ],
        [
            "เมื่อปรากฏข้อเท็จจริงว่า ขณะผู้ตายถึงแก่ความตาย ผู้ตายบรรลุนิติภาวะแล้ว โจทก์ที่ 1 ในฐานะมารดาของผู้ตาย จึงไม่มีสิทธิตามประมวลกฎหมายแพ่งและพาณิชย์ มาตรา 1567 (3) ที่จะให้ผู้ตายซึ่งเป็นบุตรทําการงานตามสมควรแก่ความสามารถและฐานานุรูป โจทก์ที่ 1 จึงไม่อาจเรียกร้องค่าขาดแรงงานได้"
        ],
        [
            "ส่วนที่โจทก์ทั้งสามฎีกาขอให้จําเลยทั้งสองร่วมกันชําระดอกเบี้ยอัตราร้อยละ 7.5 ต่อปี ของต้นเงินค่าสินไหมทดแทนนั้น เห็นว่า ตามคําฟ้องของโจทก์ทั้งสามเพียงแต่ขอให้จําเลยทั้งสองร่วมกันชดใช้ค่าสินไหมทดแทนโดยไม่ได้ขอให้จําเลยทั้งสองชําระดอกเบี้ยในค่าสินไหมทดแทนดังกล่าวมาด้วย ศาลฎีกาจึงไม่อาจกําหนดให้จําเลยทั้งสองร่วมกันชําระดอกเบี้ยให้แก่โจทก์ทั้งสามได้"
        ],
        [
            "และเมื่อผู้ตายกับโจทก์ที่ 2 ไม่ได้จดทะเบียนสมรสกัน ผู้ตายกับโจทก์ที่ 2 จึงไม่ใช่สามีภริยาที่มีหน้าที่ต้องช่วยเหลืออุปการะเลี้ยงดูกันตาม ป.พ.พ. มาตรา 1461 วรรคสอง... โจทก์ทั้งสามจึงไม่มีสิทธิที่จะเรียกร้องค่าขาดแรงงานในครอบครัวจากจําเลยทั้งสองได้"
        ]
    ],
    "ground_truth": [
        "ศาลกำหนดให้จำเลยชดใช้ค่าขาดไร้อุปการะแก่โจทก์ที่ 1 เป็นเงิน 1,000,000 บาท (หนึ่งล้านบาทถ้วน) จากเดิมที่เรียกมา 3,000,000 บาท",
        "เพราะตาม ป.พ.พ. ลักษณะ 5 (ละเมิด) หมวด 2 กรณีทำให้ถึงตาย ไม่ได้บัญญัติให้เรียกค่าสินไหมทดแทนส่วนนี้ได้ ศาลจึงไม่มีอำนาจกำหนดให้",
        "ไม่มีสิทธิ เพราะขณะตายผู้ตายบรรลุนิติภาวะแล้ว มารดาจึงไม่มีสิทธิตาม ป.พ.พ. มาตรา 1567 (3) ที่จะเรียกให้บุตรทำงานให้ได้",
        "ศาลไม่อนุญาตให้คิดดอกเบี้ย เพราะในคำฟ้องเริ่มต้น โจทก์ไม่ได้มีคำขอท้ายฟ้องให้จำเลยชำระดอกเบี้ยมาด้วย ศาลจึงกำหนดให้ไม่ได้ (เป็นการพิพากษาเกินคำขอ)",
        "ไม่มีสิทธิ เพราะโจทก์ที่ 2 ไม่ได้จดทะเบียนสมรสกับผู้ตาย จึงไม่ใช่ภริยาที่ชอบด้วยกฎหมายและไม่มีหน้าที่อุปการะเลี้ยงดูกันตาม ป.พ.พ. มาตรา 1461 วรรคสอง"
    ]
}

# --- 6. Execution Loop ---
print(f"🚀 เริ่มต้นทดสอบ RAG (Checking Hallucination & Accuracy)...")

answers_list = []
contexts_list = []
DEFAULT_CASE_ID = "5160/2566"

for q in test_inputs["question"]:
    print(f"\n❓ ถาม: {q}")
    input_payload = {"query": q, "case_id": DEFAULT_CASE_ID}

    try:
        retrieved_docs = compression_retriever.invoke(input_payload)
        print(f"   📄 เจอเอกสาร: {len(retrieved_docs)} ชิ้น")
        
        agent_ans = rag_chain.invoke(input_payload)
        print(f"   🤖 ตอบ: {agent_ans[:100]}...") 
        
        current_contexts = [doc.page_content for doc in retrieved_docs]
        
    except Exception as e:
        print(f"   ❌ Error: {e}")
        agent_ans = "Error Processing"
        current_contexts = [""]

    answers_list.append(agent_ans)
    contexts_list.append(current_contexts)

# --- 7. Evaluate with RAGAS (Using GPT-4o) ---
print("\n⚖️ Judge (GPT-4o) กำลังตรวจข้อสอบ...")

data_dict = {
    "question": test_inputs["question"],
    "answer": answers_list,
    "contexts": contexts_list,
    "ground_truth": test_inputs["ground_truth"]
}
dataset = Dataset.from_dict(data_dict)

try:
    my_run_config = RunConfig(timeout=300, max_workers=1) 

    results = evaluate(
        dataset=dataset,
        metrics=[
            answer_correctness, # ถูกต้องตามเฉลยไหม
            faithfulness,       # ตรงตาม Context ไหม (ห้ามมั่ว)
            context_precision,  # Context ที่หามาแม่นยำแค่ไหน
            context_recall,     # ✅ Context ครบถ้วนตามเฉลยไหม
            answer_relevancy    # ✅ ตอบตรงคำถามไหม
        ],
        llm=judge_llm, 
        embeddings=retrieval_embeddings, # E5-Large ถูกใช้คำนวณ answer_relevancy
        run_config=my_run_config
    )

    print("\n📊 ผลการทดสอบ:")
    print(results)
    
    df = results.to_pandas()
    df.to_csv("ragas_test_result.csv", index=False, encoding='utf-8-sig')
    print("💾 บันทึกรายงานละเอียดลงไฟล์: ragas_test_result.csv")

except Exception as e:
    print(f"\n❌ Ragas Error: {e}")

