import os
import json
from pathlib import Path
from dotenv import load_dotenv
from langchain_community.vectorstores import SupabaseVectorStore
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.documents import Document
from supabase.client import create_client, Client
from tqdm import tqdm

# --- 1. Load Config ---
# ถ้าใช้วิธีฝังค่าตรงๆ ไม่ต้องโหลด .env ก็ได้ แต่เก็บไว้ก็ไม่เสียหาย
load_dotenv("api.env")

# 🔴 แก้ไขตรงนี้: ใส่ค่าตรงๆ ไม่ต้องใช้ os.getenv
SUPABASE_URL = "https://bxosibervzfxhbwtxfop.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ4b3NpYmVydnpmeGhid3R4Zm9wIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA5MTYxODMsImV4cCI6MjA2NjQ5MjE4M30.tTzsDVq6UqjFp6FHT6v4bBVuggYZ8C-4d_S_O5jStn4"

if not SUPABASE_URL or not SUPABASE_KEY:
    raise ValueError("❌ ไม่พบ Supabase Key")

# --- 2. Setup E5 Embedding ---
print("🚀 กำลังโหลดโมเดล E5-large...")
embeddings = HuggingFaceEmbeddings(
    model_name="intfloat/multilingual-e5-large",
    model_kwargs={'device': 'cpu'} 
)

# --- 3. Connect Supabase ---
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
vector_store = SupabaseVectorStore(
    client=supabase,
    embedding=embeddings,
    table_name="legal_chunks",
    query_name="match_legal_chunks"
)

# --- 4. Load & Upload ---
# 📂 ชี้ไปที่โฟลเดอร์ที่เก็บไฟล์ JSON
INPUT_FOLDER = r"C:\Users\DLITN\Downloads\n8n Project\semantic_chunks" 

json_files = list(Path(INPUT_FOLDER).glob("*.json"))
print(f"📂 พบไฟล์ JSON ทั้งหมด: {len(json_files)} ไฟล์")

for json_file in tqdm(json_files, desc="Uploading"):
    with open(json_file, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    documents = []
    for item in data:
        doc = Document(
            page_content=item["text"],
            metadata=item["metadata"]
        )
        documents.append(doc)
    
    if documents:
        # Upload ทีละไฟล์
        vector_store.add_documents(documents)

print("✅ อัปโหลดเสร็จสิ้น! ตอนนี้ Database พร้อมใช้งานแล้ว")