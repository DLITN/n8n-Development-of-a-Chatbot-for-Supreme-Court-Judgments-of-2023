# === semantic_chunking.py (Universal + Single File Support) ===
# Features: 
# 1. Universal JSON Loader (List/Dict/Wrappers)
# 2. Semantic Split -> Compact -> Hard Cap -> Completeness Guard
# 3. Auto-detect Single File vs Folder

import os
import re
import json
import logging
from typing import List, Dict, Any
from tqdm import tqdm

# LangChain Imports
from langchain_experimental.text_splitter import SemanticChunker
from langchain.schema import Document
from langchain_huggingface import HuggingFaceEmbeddings

# === 1) CONFIGURATION ===
# ใส่ r หน้า string เพื่อกัน Error เรื่อง Backslash ใน Windows
# ตัวอย่างการใส่แบบไฟล์เดียว (Code จะรู้เอง):
INPUT_PATH  = r"C:\Users\DLITN\Downloads\n8n Project\output\json_output"
# หรือถ้าจะใส่เป็นโฟลเดอร์ ก็ใส่แบบนี้ได้เหมือนเดิม:
# INPUT_PATH  = r"C:\Users\DLITN\Downloads\n8n Project\output\json_output"

OUTPUT_FOLDER = "semantic_chunks"
MODEL_NAME    = "intfloat/multilingual-e5-large"
DEVICE        = "cpu"

# Tuning Values
SC_BREAKPOINT_TYPE   = "percentile"
SC_BREAKPOINT_AMOUNT = 0.50
MIN_CHARS_COMPACT    = 800
MAX_CHARS_HARDCAP    = 3000
OVERLAP_HARDCAP      = 200
MIN_COVERAGE_RATIO   = 0.98

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# === 2) LOGGING ===
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)

# === 3) LOAD MODEL ===
logger.info("🚀 กำลังโหลด Embedding Model: %s (Device: %s)", MODEL_NAME, DEVICE)
try:
    embeddings = HuggingFaceEmbeddings(model_name=MODEL_NAME, model_kwargs={'device': DEVICE})
    chunker = SemanticChunker(
        embeddings,
        breakpoint_threshold_type=SC_BREAKPOINT_TYPE,
        breakpoint_threshold_amount=SC_BREAKPOINT_AMOUNT
    )
except Exception as e:
    logger.exception("❌ โหลด Model ไม่สำเร็จ")
    raise e

# === 4) REGEX & HELPERS ===
RE_CASE_TITLE = re.compile(
    r"(ค[ำํ]\s*พิพากษาศาลฎีกา\s*ที่\s*[0-9๐-๙]+(?:\s*[-–]\s*[0-9๐-๙]+)?/[0-9๐-๙]{4}[^\n]*"
    r"|ค[ำํ]\s*วินิจฉัย(?:\s*\(ค[ำํ]สั่ง\))?\s*ที่\s*[0-9๐-๙]+(?:\s*[-–]\s*[0-9๐-๙]+)?/[0-9๐-๙]{4}[^\n]*)"
)
RE_COURT = re.compile(r"(ศาล[^\s\n]{0,20}?)(?=\s*ที่\b|\s|$)")
THAI_DIGITS = '๐๑๒๓๔๕๖๗๘๙'
RE_SECTION = re.compile(rf"มาตรา\s*([0-9{THAI_DIGITS}]+)")
_BOUNDARY_RE = re.compile(r"(?<=[\.\?\!]|ฯ)\s+|\n\n|\s{2,}")

def extract_anchors(text: str) -> Dict[str, Any]:
    text_clean = re.sub(r"\s+", " ", text)
    case_title = None
    m_title = RE_CASE_TITLE.search(text_clean)
    if m_title:
        case_title = m_title.group(0).strip()
    
    court = None
    m_court = RE_COURT.search(text_clean)
    if m_court:
        court = re.sub(r"\s*ที่\s*$", "", m_court.group(1).strip())

    sec_matches = RE_SECTION.findall(text)
    section_refs = sorted(list(set([f"มาตรา {s}" for s in sec_matches])))
    return {"case_title": case_title, "court": court, "section_refs": section_refs}

def _normalize_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()

def compact_small_documents(docs: List[Document], min_chars: int) -> List[Document]:
    if not docs: return []
    out = []
    buffer_doc = None
    for d in docs:
        if buffer_doc is None:
            buffer_doc = Document(page_content=d.page_content, metadata=d.metadata.copy())
            continue
        if len(_normalize_ws(buffer_doc.page_content)) >= min_chars:
            out.append(buffer_doc)
            buffer_doc = Document(page_content=d.page_content, metadata=d.metadata.copy())
        else:
            buffer_doc.page_content += "\n\n" + d.page_content
    if buffer_doc:
        out.append(buffer_doc)
    return out

def _split_hardcap(text: str, max_chars: int, overlap: int):
    if len(text) <= max_chars:
        yield text
        return
    start = 0
    text_len = len(text)
    while start < text_len:
        end = min(start + max_chars, text_len)
        if end == text_len:
            yield text[start:]
            break
        window = text[start:end]
        cut = None
        search_range = int(len(window) * 0.2)
        sub_window = window[-search_range:]
        m = list(_BOUNDARY_RE.finditer(sub_window))
        if m:
            last_match = m[-1]
            cut = (len(window) - search_range) + last_match.end()
        if cut:
            final_cut = start + cut
            yield text[start:final_cut].strip()
            start = final_cut - overlap
        else:
            yield text[start:end].strip()
            start = end - overlap

def hard_cap_documents(docs: List[Document]) -> List[Document]:
    out = []
    for d in docs:
        for piece in _split_hardcap(d.page_content, MAX_CHARS_HARDCAP, OVERLAP_HARDCAP):
            new_doc = Document(page_content=piece, metadata=d.metadata.copy())
            out.append(new_doc)
    return out

def make_chunks(text: str, base_meta: Dict) -> List[Document]:
    try:
        docs = chunker.create_documents([text])
    except Exception:
        docs = [Document(page_content=text)]

    docs = compact_small_documents(docs, MIN_CHARS_COMPACT)
    docs = hard_cap_documents(docs)

    original_len = len(_normalize_ws(text))
    new_len = sum(len(_normalize_ws(d.page_content)) for d in docs)
    if original_len > 0 and (new_len / original_len) < MIN_COVERAGE_RATIO:
        logger.warning(f"⚠️ เนื้อหาหาย ({new_len}/{original_len}) -> ใช้ Fallback")
        fallback_docs = [Document(page_content=text, metadata=base_meta)]
        docs = hard_cap_documents(fallback_docs)

    for i, d in enumerate(docs):
        d.metadata.update(base_meta)
        d.metadata["chunk_index"] = i + 1
        d.metadata["chunk_total"] = len(docs)
    return docs

# === 5) UNIVERSAL DATA LOADER (MODIFIED) ===
def process_file(filename: str, input_dir: str):
    # สร้าง Path เต็มจาก Folder + Filename
    input_path = os.path.join(input_dir, filename)
    
    # อ่านไฟล์ JSON
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # แปลง Data ให้เป็น List items เสมอ (Universal Adapter)
    items = []
    
    if isinstance(data, list):
        # Case 1: Standard List [...]
        items = data
    elif isinstance(data, dict):
        # Case 2: Dict Wrappers
        if "chunks" in data and isinstance(data["chunks"], list):
            items = data["chunks"]
        elif "pages" in data and isinstance(data["pages"], list):
            items = data["pages"]
        elif "text" in data:
            # Case 3: Single Object treated as one item
            items = [data]
        else:
            logger.error(f"❌ Skipped {filename}: JSON is dict but no 'chunks', 'pages', or 'text' key found.")
            return
    else:
        logger.error(f"❌ Skipped {filename}: Unsupported JSON format type {type(data)}")
        return

    all_chunks = []
    
    # Process items
    for entry in items:
        # ดึง text ให้ได้ไม่ว่าจะ key ชื่ออะไร
        text = entry.get("text", entry.get("page_content", ""))
        
        # Metadata fallback
        judgment_id = entry.get("judgment_id", entry.get("doc_id", "unknown"))
        # ถ้าไม่มี source ใน item ให้ใช้ชื่อไฟล์
        source = entry.get("source", filename)
        
        # Skip empty
        if not text or not text.strip(): 
            continue

        anchors = extract_anchors(text)
        
        base_meta = {
            "judgment_id": judgment_id,
            "source": source,
            "case_title": anchors["case_title"],
            "court": anchors["court"],
            "section_refs": anchors["section_refs"],
            "year": 2566
        }

        chunks = make_chunks(text, base_meta)
        
        for c in chunks:
            all_chunks.append({
                "text": c.page_content,
                "metadata": c.metadata
            })

    # Save Output
    out_path = os.path.join(OUTPUT_FOLDER, filename)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, ensure_ascii=False, indent=2)
    
    logger.info(f"✅ Saved: {filename} ({len(all_chunks)} chunks)")

# === 6) ENTRY POINT (MODIFIED) ===
def main():
    if not os.path.exists(INPUT_PATH):
        logger.error(f"ไม่พบไฟล์หรือโฟลเดอร์: {INPUT_PATH}")
        return

    # ตรวจสอบว่าเป็นไฟล์เดียว หรือเป็นโฟลเดอร์
    if os.path.isfile(INPUT_PATH):
        # กรณี: ใส่ Path มาเป็นไฟล์ (1.json)
        target_dir = os.path.dirname(INPUT_PATH) # หาโฟลเดอร์แม่ (json_output)
        target_files = [os.path.basename(INPUT_PATH)] # ชื่อไฟล์ (1.json)
        logger.info(f"🔎 ตรวจพบโหมดไฟล์เดียว: กำลังประมวลผล {target_files[0]}")
    else:
        # กรณี: ใส่ Path มาเป็นโฟลเดอร์
        target_dir = INPUT_PATH
        target_files = [f for f in os.listdir(target_dir) if f.lower().endswith(".json")]
        logger.info(f"📂 ตรวจพบโหมดโฟลเดอร์: พบไฟล์ JSON ทั้งหมด {len(target_files)} ไฟล์")

    # เริ่ม Loop ประมวลผล
    for f in tqdm(target_files, desc="Processing"):
        try:
            # ส่ง target_dir แยกไปด้วย เพื่อให้ process_file รู้ว่าต้องอ่านจากไหน
            process_file(f, target_dir)
        except Exception as e:
            logger.error(f"❌ Error processing {f}: {e}")

    logger.info("🎉 เสร็จสิ้นกระบวนการ Semantic Chunking ทั้งหมด")

if __name__ == "__main__":
    main()