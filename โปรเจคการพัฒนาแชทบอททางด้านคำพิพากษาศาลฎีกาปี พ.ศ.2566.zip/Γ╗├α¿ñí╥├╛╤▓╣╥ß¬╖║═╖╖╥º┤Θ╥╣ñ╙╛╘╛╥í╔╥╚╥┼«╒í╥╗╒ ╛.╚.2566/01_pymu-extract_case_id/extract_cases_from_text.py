import os
import re
import json
from tqdm import tqdm

INPUT_FOLDER = r"C:\Users\DLITN\Downloads\n8n Project\output\extracted_texts"  # โฟลเดอร์ที่เก็บไฟล์ .txt จากขั้นตอนแรก
OUTPUT_FOLDER = r"C:\Users\DLITN\Downloads\n8n Project\output\json_output" 
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Regex จับหัวข้อ (แบบ Robust)
CASE_HEADER_PATTERN = re.compile(
    r"(?:^|\n)(?:.){0,10}?"             # ยอมให้มีขยะข้างหน้าเล็กน้อย (เผื่อสระลอย)
    r"(พิพากษาศาลฎีกา|วินิจฉัย|สั่ง)"    # คำหลัก
    r"(?:\s*\(.*?\))?"                  # เผื่อมีวงเล็บ
    r"\s*ที่\s*"                        # คำว่า "ที่"
    r"([\d๐-๙\s\-–,]+/\s*[\d๐-๙]{4})",  # เลขคดี
    re.MULTILINE | re.UNICODE
)

def clean_case_id(text_id):
    t = text_id.strip()
    t = re.sub(r"\s+", "", t)
    return t.translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙', '0123456789'))

def split_text_by_cases(full_text):
    matches = list(CASE_HEADER_PATTERN.finditer(full_text))
    valid_matches = []
    
    for m in matches:
        start_pos = m.start()
        # ตรวจสอบข้อความ 300 ตัวอักษรหลังจากหัวข้อ
        context_window = full_text[start_pos : start_pos + 300]
        
        # --- LOGIC FILTER ที่แก้ไขแล้ว ---
        # หัวข้อคดีจริง ต้องมีคำว่า "โจทก์", "ผู้ร้อง", หรือ "อัยการ" ปรากฏอยู่ใกล้ๆ
        # ตัดคำว่า "จำเลย" ออกจากเงื่อนไข เพราะการอ้างอิง (Citation) มักพูดถึงจำเลย ทำให้สับสน
        if re.search(r"(โจทก์|ผู้ร้อง|พนักงานอัยการ|อัยการ)", context_window):
            valid_matches.append(m)
        else:
            # Debug: แสดงสิ่งที่ถูกตัดออก (ว่าเป็น Citation)
            skipped_id = m.group(2).strip()
            print(f"   ⚠️ ข้าม Citation (ไม่ใช่คดีหลัก): {skipped_id}")

    if not valid_matches:
        return [{"judgment_id": "unknown", "case_title": "Unknown", "text": full_text}]

    cases = []
    for i, match in enumerate(valid_matches):
        start_idx = match.start()
        end_idx = valid_matches[i+1].start() if (i + 1) < len(valid_matches) else len(full_text)
        
        case_text = full_text[start_idx:end_idx].strip()
        raw_id = match.group(2)
        jid = clean_case_id(raw_id)
        
        # สร้าง Title
        full_title = "คำ" + match.group(1).strip() + "ที่ " + raw_id.strip() 
        full_title = re.sub(r"\s+", " ", full_title)

        cases.append({
            "judgment_id": jid,
            "case_title": full_title,
            "text": case_text
        })
        
    return cases

def process_files():
    files = [f for f in os.listdir(INPUT_FOLDER) if f.endswith(".txt")]
    print(f"📂 พบไฟล์ .txt จำนวน {len(files)} ไฟล์")

    for filename in tqdm(files):
        file_path = os.path.join(INPUT_FOLDER, filename)
        with open(file_path, "r", encoding="utf-8") as f:
            full_text = f.read()

        cases = split_text_by_cases(full_text)
        
        output_data = []
        for c in cases:
            output_data.append({
                "judgment_id": c["judgment_id"],
                "case_title": c["case_title"],
                "source": filename,
                "text": c["text"]
            })

        out_name = filename.replace(".txt", ".json")
        with open(os.path.join(OUTPUT_FOLDER, out_name), "w", encoding="utf-8") as out:
            json.dump(output_data, out, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    process_files()