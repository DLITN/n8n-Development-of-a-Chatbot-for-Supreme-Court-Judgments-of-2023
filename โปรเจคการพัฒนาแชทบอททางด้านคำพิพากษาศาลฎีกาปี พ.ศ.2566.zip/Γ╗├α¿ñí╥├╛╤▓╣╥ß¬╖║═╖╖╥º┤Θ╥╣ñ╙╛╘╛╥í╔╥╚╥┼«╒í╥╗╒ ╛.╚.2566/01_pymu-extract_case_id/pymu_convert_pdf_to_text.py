# 01_text/convert_pdf_to_text.py
# Robust PDF -> Text extractor (Thai legal) with:
# - normalization (+no end-of-page typo fixing),
# - header/footer & noise filtering,
# - improved case_id detection (คำวินิจฉัย/คำสั่ง/คำพิพากษาศาลฎีกา + Thai digits + ranges),
# - range expansion (e.g., 5234-5238/2566 -> 5234/2566 ... 5238/2566),
# - per-file/page metadata, OCR fallback (optional).

import os
import re
import sys
import json
import hashlib
import logging
import argparse
import unicodedata
from typing import List, Dict, Tuple

import fitz  # PyMuPDF

# Optional OCR deps (can be disabled by --no-ocr)
try:
    import pytesseract  # noqa: F401
    from pdf2image import convert_from_path  # noqa: F401
    OCR_AVAILABLE = True
except Exception:
    OCR_AVAILABLE = False

# ----------------------------
# Normalization & Utilities
# ----------------------------

THAI_DIGITS = '๐๑๒๓๔๕๖๗๘๙'
ARABIC_DIGITS = '0123456789'
TRANS_THAI_TO_ARABIC = str.maketrans(THAI_DIGITS, ARABIC_DIGITS)

ZERO_WIDTHS = ["\u200b", "\u200c", "\u200d", "\ufeff"]

HEADER_FOOTER_KEYWORDS = [
    r"^แหล่งที่มา",
    r"^หมายเหตุ",
]

# Expanded noise patterns
NOISE_LINE_PATTERNS = [
    r"^_{5,}$",                 # __________
    r"^-{3,}$",                 # ----
    r"^\(ไม่มี\s*-\)$",         # (ไม่มี -)
    r"^-$",                     # -
    r"^[•·∙●○◦\*\u2022]{1,}\s*$",  # bullets alone
    r"^\(\s*\)$",               # empty parentheses
    r"^หน้า\s*\d+\s*$",         # page marker alone
    r"^สํานักงานเลขานุการคณะกรรมการวินิจฉัย.*$",
]

def thai_num_to_arabic(text: str) -> str:
    return text.translate(TRANS_THAI_TO_ARABIC)

def normalize_th(text: str) -> str:
    # Do NOT fix end-of-page garbled chars (as requested)
    text = unicodedata.normalize("NFKC", text)
    for z in ZERO_WIDTHS:
        text = text.replace(z, "")
    text = thai_num_to_arabic(text)
    lines = [ln.strip() for ln in text.splitlines()]
    cleaned: List[str] = []
    for ln in lines:
        if ln or (cleaned and cleaned[-1]):  # allow single empty line
            cleaned.append(ln)
    return "\n".join(cleaned)

def md5_str(s: str) -> str:
    return hashlib.md5(s.encode("utf-8")).hexdigest()

def text_density(s: str) -> float:
    if not s:
        return 0.0
    non_space = sum(1 for ch in s if not ch.isspace())
    return non_space / max(len(s), 1)

# ----------------------------
# Header/Footer trimming + Noise filtering
# ----------------------------

def is_noise_line(ln: str) -> bool:
    for pat in NOISE_LINE_PATTERNS:
        if re.search(pat, ln):
            return True
    return False

def trim_header_footer(lines: List[str], header_max=3, footer_max=5) -> List[str]:
    if not lines:
        return lines
    page_mark = re.compile(r"(หน้า|page)\s*\d+", re.IGNORECASE)

    head = lines[:header_max]
    tail = lines[-footer_max:] if len(lines) > footer_max else []

    def drop_count(seq: List[str]) -> int:
        drop = 0
        for s in seq:
            if len(s) <= 4 or page_mark.search(s):
                drop += 1
            else:
                for kw in HEADER_FOOTER_KEYWORDS:
                    if re.search(kw, s):
                        drop += 1
                        break
        return drop

    drop_head = drop_count(head)
    drop_tail = drop_count(tail)

    middle = lines[drop_head: len(lines) - drop_tail if drop_tail else None]
    middle = [
        ln for ln in middle
        if not any(re.search(kw, ln) for kw in HEADER_FOOTER_KEYWORDS)
        and not is_noise_line(ln)
    ]
    return middle

# ----------------------------
# Extraction strategies
# ----------------------------

def extract_page_text(page: fitz.Page) -> str:
    modes = ["text", "blocks", "rawdict"]
    for mode in modes:
        try:
            if mode == "rawdict":
                raw = page.get_text("rawdict")
                parts: List[str] = []
                for b in raw.get("blocks", []):
                    for l in b.get("lines", []):
                        line_text = "".join(sp.get("text", "") for sp in l.get("spans", []))
                        if line_text.strip():
                            parts.append(line_text)
                txt = "\n".join(parts)
            else:
                txt = page.get_text(mode)
            if txt and text_density(txt) > 0.02:
                return txt
        except Exception:
            continue
    return ""

def ocr_page_images(doc_path: str, page_index: int, dpi=300) -> str:
    if not OCR_AVAILABLE:
        return ""
    from pdf2image import convert_from_path
    import pytesseract
    images = convert_from_path(doc_path, dpi=dpi, first_page=page_index+1, last_page=page_index+1)
    if not images:
        return ""
    try:
        return pytesseract.image_to_string(images[0], lang="tha+eng")
    except Exception:
        return ""

# ----------------------------
# case_id detection (improved)
# ----------------------------

# รูปแบบหัวเรื่องที่รองรับ:
# - คำวินิจฉัยที่ 9/2566
# - คำวินิจฉัย(คำสั่ง)ที่ 55/2566
# - คำพิพากษาศาลฎีกาที่ 5234-5238/2566  (ช่วงหมายเลข)
CASE_ID_ARABIC = re.compile(
    r"(?:ค[ำํ]\s*วินิจฉัย(?:\s*\(ค[ำํ]สั่ง\))?|ค[ำํ]\s*พิพากษาศาลฎีกา)"
    r"\s*ที่\s*([0-9]+(?:\s*[-–]\s*[0-9]+)?/[0-9]{4})",
    re.IGNORECASE | re.UNICODE
)
CASE_ID_THAI = re.compile(
    rf"(?:ค[ำํ]\s*วินิจฉัย(?:\s*\(ค[ำํ]สั่ง\))?|ค[ำํ]\s*พิพากษาศาลฎีกา)"
    rf"\s*ที่\s*([{THAI_DIGITS}]+(?:\s*[-–]\s*[{THAI_DIGITS}]+)?/[{THAI_DIGITS}]{{4}})",
    re.IGNORECASE | re.UNICODE
)

def thai_to_arabic_num(s: str) -> str:
    return s.translate(TRANS_THAI_TO_ARABIC)

def expand_case_range(cid: str) -> List[str]:
    """
    รับรูปแบบ "5234-5238/2566" หรือ "5234/2566" → คืน list ของ case_ids
    มี guard ไม่ขยายช่วงยาวเกินไป
    """
    m = re.match(r"^\s*(\d+)(?:\s*[-–]\s*(\d+))?/(\d{4})\s*$", cid)
    if not m:
        return [cid]
    start, end, year = m.group(1), m.group(2), m.group(3)
    if not end:
        return [f"{int(start)}/{year}"]
    s, e = int(start), int(end)
    if e < s or e - s > 50:
        return [cid]  # ป้องกันช่วงผิดปกติ
    return [f"{i}/{year}" for i in range(s, e + 1)]

def collect_case_headings(blob: str, allow_thai_digits: bool) -> Tuple[List[str], List[str]]:
    """
    คืน (expanded_case_ids, raw_headings)
    - raw_headings: ค่าที่จับได้ดิบ ๆ เช่น "5234-5238/2566"
    - expanded_case_ids: ขยายช่วงเป็นหลายค่าแล้ว (หรือเดี่ยว)
    """
    expanded: List[str] = []
    raw_hits: List[str] = []

    # Arabic first
    for m in CASE_ID_ARABIC.finditer(blob):
        raw = m.group(1)
        raw_hits.append(raw)
        for cid in expand_case_range(raw):
            if cid not in expanded:
                expanded.append(cid)

    if allow_thai_digits:
        for m in CASE_ID_THAI.finditer(blob):
            raw_th = m.group(1)
            raw_hits.append(raw_th)
            raw_ar = thai_to_arabic_num(raw_th)
            for cid in expand_case_range(raw_ar):
                if cid not in expanded:
                    expanded.append(cid)

    return expanded, raw_hits

def extract_case_ids_and_heads(text_norm: str, text_raw: str = "") -> Tuple[List[str], List[str]]:
    """
    ดึง case_ids (ขยายช่วงแล้ว) และ raw_case_headings (สตริงที่พบ) จากทั้ง norm และ raw
    """
    seen_ids: List[str] = []
    seen_heads: List[str] = []

    def merge(ids: List[str], heads: List[str]):
        nonlocal seen_ids, seen_heads
        for x in ids:
            if x not in seen_ids:
                seen_ids.append(x)
        for h in heads:
            if h not in seen_heads:
                seen_heads.append(h)

    # จาก normalized
    ids, heads = collect_case_headings(text_norm, allow_thai_digits=False)
    merge(ids, heads)

    # จาก normalized แต่รองรับเลขไทย (เผื่อ normalize ยังมีตัวเลขไทยหลง)
    ids_th, heads_th = collect_case_headings(text_norm, allow_thai_digits=True)
    merge(ids_th, heads_th)

    # จาก raw (รวมช่องว่างแปลก ๆ)
    if text_raw:
        raw_join = re.sub(r"\s+", " ", text_raw)
        ids2, heads2 = collect_case_headings(raw_join, allow_thai_digits=False)
        merge(ids2, heads2)
        ids2_th, heads2_th = collect_case_headings(raw_join, allow_thai_digits=True)
        merge(ids2_th, heads2_th)

    return seen_ids, seen_heads

# ----------------------------
# Core: extract PDF -> (full_text, json_payload)
# ----------------------------

def extract_text_from_pdf(pdf_path: str,
                          enable_ocr_fallback: bool = True,
                          trim_headers: bool = True,
                          default_lang: str = "th",
                          default_year: int = 2566) -> Tuple[str, dict]:
    doc = fitz.open(pdf_path)
    chunks: List[Dict] = []
    full_text_parts: List[str] = []

    source_file = os.path.basename(pdf_path)
    doc_id = os.path.splitext(source_file)[0]

    for i, page in enumerate(doc):
        raw = extract_page_text(page)

        if enable_ocr_fallback and (text_density(raw) < 0.02):
            ocr_txt = ocr_page_images(pdf_path, i)
            if text_density(ocr_txt) > text_density(raw):
                raw = ocr_txt

        norm = normalize_th(raw)
        if trim_headers:
            norm_lines = trim_header_footer(norm.splitlines())
            norm = "\n".join(norm_lines)

        # improved: case_id detection (both norm & raw) + range expansion
        case_ids, raw_heads = extract_case_ids_and_heads(norm, raw)

        page_meta = {
            "source": source_file,
            "doc_id": doc_id,
            "judgment_id": doc_id,        # backward-compatible with step 02
            "page_number": i + 1,
            "lang": default_lang,
            "year": default_year,
            "case_ids": case_ids,         # expanded case ids list
            "raw_case_headings": raw_heads,  # raw strings captured (e.g., "5234-5238/2566")
        }
        chunk_md5 = md5_str(norm + json.dumps(page_meta, ensure_ascii=False, sort_keys=True))
        page_meta["chunk_md5"] = chunk_md5

        page_chunk = {
            "page": i + 1,
            "text": norm,
            "stats": {
                "chars": len(norm),
                "density": round(text_density(norm), 4),
            },
            "metadata": page_meta
        }
        chunks.append(page_chunk)

        full_text_parts.append(f"--- Page {i+1} ---\n{norm}".rstrip())

    full_text = "\n\n".join(full_text_parts).strip()

    file_meta = {
        "source_file": source_file,
        "doc_id": doc_id,
        "lang": default_lang,
        "year": default_year,
        "num_pages": len(doc),
        "md5_full_text": md5_str(full_text),
    }

    json_payload = {
        "meta": file_meta,
        "chunks": chunks
    }

    return full_text, json_payload

# ----------------------------
# I/O & CLI
# ----------------------------

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def save_txt(out_path: str, text: str):
    ensure_dir(os.path.dirname(out_path))
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)

def save_json(out_path: str, obj: dict):
    ensure_dir(os.path.dirname(out_path))
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def setup_logging(verbose: bool):
    logging.basicConfig(
        level=logging.INFO if verbose else logging.WARNING,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

def process_folder(input_dir: str,
                   output_dir: str,
                   enable_ocr_fallback: bool = True,
                   trim_headers: bool = True):
    pdfs = [f for f in os.listdir(input_dir) if f.lower().endswith(".pdf")]
    if not pdfs:
        logging.warning("No PDF files found in input directory: %s", input_dir)

    for fn in sorted(pdfs):
        in_path = os.path.join(input_dir, fn)
        stem = os.path.splitext(fn)[0]
        txt_out = os.path.join(output_dir, "extracted_texts", f"{stem}.txt")
        json_out = os.path.join(output_dir, "json_output", f"{stem}.json")

        logging.info("Reading: %s", fn)
        try:
            full_text, json_payload = extract_text_from_pdf(
                in_path,
                enable_ocr_fallback=enable_ocr_fallback,
                trim_headers=trim_headers,
            )
            save_txt(txt_out, full_text)
            save_json(json_out, json_payload)
            logging.info("Saved: %s ; %s", txt_out, json_out)
            print(f"✅ {fn} -> .txt & .json saved")
        except Exception as e:
            logging.exception("Failed to process %s: %s", fn, e)
            print(f"❌ Failed: {fn} ({e})")

def main():
    parser = argparse.ArgumentParser(description="Extract Thai legal PDFs to text with metadata and improved case_id detection (incl. ranges).")
    parser.add_argument("--input", "-i", required=False,
                        default=os.path.join(os.getcwd(), "PDF"),
                        help="Input folder containing .pdf files (default: ./PDF)")
    parser.add_argument("--output", "-o", required=False,
                        default=os.path.join(os.getcwd(), "output"),
                        help="Output folder (default: ./output)")
    parser.add_argument("--no-ocr", action="store_true",
                        help="Disable OCR fallback (default: enabled if dependencies available)")
    parser.add_argument("--no-trim-header", action="store_true",
                        help="Disable header/footer trimming heuristic")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Verbose logging")

    args = parser.parse_args()

    setup_logging(args.verbose)

    if args.no_ocr:
        enable_ocr = False
    else:
        enable_ocr = OCR_AVAILABLE
        if not OCR_AVAILABLE:
            logging.warning("OCR fallback requested/assumed but dependencies not available. Proceeding without OCR.")

    inp = os.path.abspath(args.input)
    out = os.path.abspath(args.output)

    if not os.path.isdir(inp):
        print(f"❌ Input folder not found: {inp}")
        sys.exit(1)

    print(f"📂 Input : {inp}")
    print(f"📁 Output: {out}")
    print(f"🧠 OCR fallback: {'ON' if enable_ocr else 'OFF'}")
    print(f"✂️  Trim header/footer: {'ON' if not args.no_trim_header else 'OFF'}")

    process_folder(
        input_dir=inp,
        output_dir=out,
        enable_ocr_fallback=enable_ocr,
        trim_headers=not args.no_trim_header
    )

if __name__ == "__main__":
    main()
