# === upload_to_supabase.py ===
# Features: 
# - Loads config from .env automatically
# - Retry Logic for connection stability
# - Auto-detect Single File vs Folder Input

import os
import json
import time
import hashlib
import argparse
import logging
from typing import List, Dict, Any, Optional
import numpy as np
from tqdm import tqdm

# Libraries
from sentence_transformers import SentenceTransformer
from supabase import create_client, Client

# --- LOAD .ENV ---
try:
    from dotenv import load_dotenv
    # ระบุ Path ของไฟล์ .env ให้ชัดเจน
    env_path = r"C:\Users\DLITN\Downloads\n8n Project\05_send_to_vector_database\supabase.env"
    print(f"⚙️ Loading config from: {env_path}")
    load_dotenv(env_path)
except ImportError:
    print("⚠️ Warning: 'python-dotenv' not installed.")

# === 1. CONFIGURATION ===
# อ่านค่าจาก .env (ถ้าใน .env ไม่มี จะใช้ค่า Default ด้านหลัง)
# ค่า Default ตั้งเป็นโฟลเดอร์ไว้ก่อน
DEFAULT_INPUT_PATH = os.getenv("INPUT_PATH", r"C:\Users\DLITN\Downloads\n8n Project\semantic_chunks")

# ถ้าอยากบังคับให้ test แค่ไฟล์ 1.json ให้แก้ 

# Supabase Config (อ่านจาก .env เท่านั้น)
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

# Model Settings
TABLE_NAME = "legal_chunks"
MODEL_NAME = "intfloat/multilingual-e5-large"
EMBED_DIM = 1024
BATCH_SIZE = 50

# === 2. LOGGING ===
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)

# === 3. HELPER FUNCTIONS ===

def md5_str(s: str) -> str:
    return hashlib.md5(s.encode("utf-8")).hexdigest()

def sanitize_json(obj: Any) -> Any:
    """ป้องกัน error จากค่า NaN หรือ Infinity ที่ JSON มาตรฐานไม่รองรับ"""
    if isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return obj
    if isinstance(obj, dict):
        return {k: sanitize_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_json(v) for v in obj]
    return obj

def load_data(path: str) -> List[Dict]:
    """โหลดไฟล์ JSON ไม่ว่าจะเป็นไฟล์เดียวหรือโฟลเดอร์"""
    all_records = []
    
    # ตรวจสอบว่า Path มีอยู่จริงไหม
    if not os.path.exists(path):
        logger.error(f"❌ ไม่พบไฟล์หรือโฟลเดอร์: {path}")
        return []

    # กำหนดรายการไฟล์
    if os.path.isfile(path):
        files = [path]
        logger.info(f"🔎 โหมดไฟล์เดียว: {path}")
    elif os.path.isdir(path):
        files = [os.path.join(path, f) for f in os.listdir(path) if f.lower().endswith(".json")]
        logger.info(f"📂 โหมดโฟลเดอร์: พบ {len(files)} ไฟล์ใน {path}")
    else:
        return []

    for fpath in files:
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                data = json.load(f)
                # รองรับทั้งแบบ List [...] และ Dict wrapper { "chunks": [...] }
                if isinstance(data, dict) and "chunks" in data:
                    data = data["chunks"]
                if isinstance(data, list):
                    all_records.extend(data)
        except Exception as e:
            logger.error(f"⚠️ อ่านไฟล์พลาด {fpath}: {e}")
            
    return all_records

def prepare_payload(rec: Dict) -> Optional[Dict]:
    """แปลง Data ให้ตรงกับ Schema ของ Table ใน Supabase"""
    text = rec.get("text", "").strip()
    if not text: return None
    
    md = rec.get("metadata", {})
    
    # สร้าง ID กันซ้ำ (Unique Key) โดยใช้ hash
    unique_str = f"{md.get('judgment_id')}|{md.get('chunk_index')}|{md5_str(text)}"
    row_id = md5_str(unique_str)

    # Map fields ให้ตรงกับ SQL Table
    return {
        "chunk_md5": row_id,
        "text": text,
        "doc_id": md.get("judgment_id") or md.get("doc_id"),
        "case_id": md.get("judgment_id"),
        "case_title": md.get("case_title"),
        "court": md.get("court"),
        "year": md.get("year"),
        # จัดการ page_range ที่อาจมาเป็น list หรือ int เดี่ยวๆ
        "page_start": md.get("page_range")[0] if isinstance(md.get("page_range"), list) else md.get("page_number"),
        "page_end": md.get("page_range")[1] if isinstance(md.get("page_range"), list) and len(md.get("page_range")) > 1 else md.get("page_number"),
        "metadata": md  # เก็บ Metadata ดิบไว้เผื่อใช้
    }

def batchify(data, size):
    for i in range(0, len(data), size):
        yield data[i:i + size]

# === 4. CORE LOGIC ===

def main():
    # 1. Check Config & Connect Supabase
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.error("❌ ไม่พบ SUPABASE_URL หรือ SUPABASE_KEY ในไฟล์ .env")
        logger.info("💡 กรุณาสร้างไฟล์ .env และใส่ค่า: SUPABASE_URL=... และ SUPABASE_KEY=...")
        return
    
    try:
        supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
    except Exception as e:
        logger.error(f"❌ เชื่อมต่อ Supabase ไม่สำเร็จ: {e}")
        return
    
    # 2. Load Data
    logger.info(f"📥 กำลังอ่านข้อมูลจาก: {DEFAULT_INPUT_PATH}")
    raw_data = load_data(DEFAULT_INPUT_PATH)
    if not raw_data:
        logger.warning("⚠️ ไม่พบข้อมูล JSON หรือโฟลเดอร์ว่างเปล่า")
        return
        
    # เตรียม Payload (ยังไม่มี embedding vector)
    payloads = []
    texts_to_embed = []
    
    for r in raw_data:
        p = prepare_payload(r)
        if p:
            payloads.append(p)
            texts_to_embed.append(p["text"])
            
    logger.info(f"✅ เตรียมข้อมูลเสร็จสิ้น: {len(payloads)} รายการ")

    # 3. Load Model & Embed
    logger.info(f"🧠 กำลังโหลดโมเดล: {MODEL_NAME} ...")
    try:
        model = SentenceTransformer(MODEL_NAME)
    except Exception as e:
        logger.error(f"❌ โหลดโมเดลไม่สำเร็จ: {e}")
        return
    
    logger.info("🚀 เริ่มสร้าง Embeddings (อาจใช้เวลาสักครู่)...")
    # E5 Model ต้องการ prefix "passage: " สำหรับ document เพื่อประสิทธิภาพสูงสุด
    prefixed_texts = [f"passage: {t}" for t in texts_to_embed]
    
    embeddings = model.encode(
        prefixed_texts, 
        batch_size=32, 
        show_progress_bar=True, 
        normalize_embeddings=True
    )

    # 4. Merge Vector & Upload
    logger.info("☁️ กำลังอัปโหลดขึ้น Supabase...")
    
    # เอา Vector ยัดกลับเข้าไปใน Payload
    for i, payload in enumerate(payloads):
        payload["embedding"] = embeddings[i].tolist()

    # Upload แบบ Batch พร้อม Retry Logic
    total_uploaded = 0
    for batch in tqdm(list(batchify(payloads, BATCH_SIZE)), desc="Upserting"):
        sanitized_batch = sanitize_json(batch)
        
        # Retry Loop (ลองใหม่ถ้าเน็ตหลุด)
        max_retries = 3
        for attempt in range(max_retries):
            try:
                supabase.table(TABLE_NAME).upsert(sanitized_batch, on_conflict="chunk_md5").execute()
                total_uploaded += len(batch)
                break # สำเร็จแล้วออกจาก loop retry
            except Exception as e:
                logger.warning(f"⚠️ Upload failed (Attempt {attempt+1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 * (attempt + 1)) # รอสักพักก่อนลองใหม่ (Exponential Backoff)
                else:
                    logger.error("❌ ข้าม Batch นี้เนื่องจาก Error ถาวร")

    logger.info(f"🎉 เสร็จสิ้น! อัปโหลดข้อมูลไปทั้งสิ้น {total_uploaded} รายการ")

if __name__ == "__main__":
    main()